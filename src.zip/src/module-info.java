
module online {
	requires java.sql;
	exports mini;
}